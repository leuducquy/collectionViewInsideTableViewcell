var express = require('express');

var app = express();

app.get('/wines', function(req, res) {
    res.send([{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}

    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ,{name:'wine1',image : 'http://avatar.nct.nixcdn.com/singer/avatar/2016/06/03/2/c/e/0/1464948474689.jpg'}
    ]);
});
app.get('/wines/:id', function(req, res) {
    res.send({id:req.params.id, name: "The Name", description: "description"});
});

app.listen(3000);
console.log('Listening on port 3000...');
